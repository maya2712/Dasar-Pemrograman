﻿using System;
using System.Collections.Generic;
using System.IO;


namespace Soal_No_2_DESIMAYASARI
{
    class Program
    {
        static void Main()
        {
            string[] Katakata = File.ReadAllLines("Kata.txt");
            Random rnd = new Random();
            string kata = Katakata[rnd.Next(1,14)];
            int kesempatan = 10;
            List<string> hurufTebakanUser = new List<string>{};

            Console.WriteLine("");
            Console.WriteLine(">>>===============================================<<<");
            Console.WriteLine("   | Selamat datang, mari bermain Game Tebak Kata |  ");
            Console.WriteLine(">>>===============================================<<<");

            while (true)
            {
                Console.Clear();
                Console.WriteLine("");
                Console.WriteLine(">>>===============================================<<<");
                Console.WriteLine("  |                   WELCOME TO                 |   ");
                Console.WriteLine("  |                Game Tebak Kata               |   ");
                Console.WriteLine(">>>===============================================<<<");
                Console.WriteLine("");
               
                             
            if(kesempatan == 9)
            {
                Console.WriteLine("/_ _        ");
                Console.WriteLine("");
            }          
            if(kesempatan == 8)
            {
                Console.WriteLine("|      ");
                Console.WriteLine("|      " );
                Console.WriteLine("|      ");
                Console.WriteLine("/_ _    ");
                Console.WriteLine("");
            }           
            if(kesempatan == 7)
            {
                Console.WriteLine("|/      ");
                Console.WriteLine("|       ");
                Console.WriteLine("|      ");
                Console.WriteLine("|      " );
                Console.WriteLine("|      ");
                Console.WriteLine("/_ _    ");
                Console.WriteLine("");
            }         
            if(kesempatan == 6)
            {
                Console.WriteLine("_____    ");
                Console.WriteLine("|/       ");
                Console.WriteLine("|        ");
                Console.WriteLine("|        ");
                Console.WriteLine("|        ");
                Console.WriteLine("|        ");
                Console.WriteLine("/_ _     ");
                Console.WriteLine("");
            }
            if(kesempatan == 5)
            {
                Console.WriteLine("____________");
                Console.WriteLine("|/          ");
                Console.WriteLine("|           ");
                Console.WriteLine("|           ");
                Console.WriteLine("|           ");
                Console.WriteLine("|           ");
                Console.WriteLine("/_ _        ");
                Console.WriteLine("");
            }   
            if(kesempatan == 4)
            {
                Console.WriteLine("____________");
                Console.WriteLine("|/       |"  );
                Console.WriteLine("|       (_) ");
                Console.WriteLine("|           ");
                Console.WriteLine("|           ");
                Console.WriteLine("|           ");
                Console.WriteLine("/_ _        ");
                Console.WriteLine("");
            }
            if(kesempatan == 3)
            {
                Console.WriteLine("____________ ");
                Console.WriteLine("|/       |   ");
                Console.WriteLine("|       (_)  ");
                Console.WriteLine(@"|       \|/  ");
                Console.WriteLine("|            ");
                Console.WriteLine("|            ");
                Console.WriteLine("/_ _         ");
            }
            if(kesempatan == 2)
            {
                Console.WriteLine("____________");
                Console.WriteLine("|/       |  ");
                Console.WriteLine("|       (_) ");
                Console.WriteLine(@"|       \|/ ");
                Console.WriteLine("|        |  ");
                Console.WriteLine("|           ");
                Console.WriteLine("/_ _        ");
                Console.WriteLine("");
            } 
            if(kesempatan == 1)
            {
                Console.WriteLine("____________");
                Console.WriteLine("|/       |");
                Console.WriteLine("|       (_)");
                Console.WriteLine(@"|       \|/");
                Console.WriteLine("|        |" );
                Console.WriteLine(@"|       /|\");
                Console.WriteLine("/_ _        ");
                Console.WriteLine("");
            }
             if(kesempatan == 0)
                {
                    Console.WriteLine("");
                    Console.WriteLine("            * PERMAINAN SUDAH BERAKHIR *             ");
                    Console.WriteLine("");
                    Console.WriteLine("");
                    Console.WriteLine(">>>===============================================<<<");
                    Console.WriteLine("                     GAME OVER                       ");
                    Console.WriteLine("             Tebakannya adalah ["+kata+"]            ");
                    Console.WriteLine("                     SEE YOU ...                     ");
                    Console.WriteLine(">>>===============================================<<<");
                    Console.WriteLine("");
                    break;
                }
             Console.WriteLine(cekHuruf(kata, hurufTebakanUser));
                Console.Write("Apakah huruf tebakan mu? ");
                string input = Console.ReadLine();

                hurufTebakanUser.Add(input);
                if(cekKata(kata,hurufTebakanUser))
                {
                    Console.WriteLine("");
                    Console.WriteLine("            * PERMAINAN SUDAH BERAKHIR *             ");
                    Console.WriteLine("");
                    Console.WriteLine("");
                    Console.WriteLine(">>>===============================================<<<");
                    Console.WriteLine("                 **CONGRATULATION**                  ");
                    Console.WriteLine("     Anda berhasil, Tebakannya adalah... ["+kata+"]  ");
                    Console.WriteLine("                     SEE YOU ...                     ");
                    Console.WriteLine(">>>===============================================<<<");
                    break;
                }
                  if(kesempatan == 0)
                {
                    Console.WriteLine("");
                    Console.WriteLine("            * PERMAINAN SUDAH BERAKHIR *             ");
                    Console.WriteLine("");
                    Console.WriteLine(">>>===============================================<<<");
                    Console.WriteLine("                     GAME OVER                       ");
                    Console.WriteLine("             Tebakannya adalah ["+kata+"]            ");
                    Console.WriteLine("                     SEE YOU ...                     ");
                    Console.WriteLine(">>>===============================================<<<");
                    Console.WriteLine("");
                    break;
                }else if(kata.Contains(input))
                {
                    Console.WriteLine(cekHuruf(kata, hurufTebakanUser));
                    Console.WriteLine("Huruf Tebakan 'BENAR' : ");
                }else
                {
                    Console.WriteLine("MAAF Tebakan Huruf Kamu 'SALAH' :( ");
                    kesempatan = kesempatan - 1;
                    Console.WriteLine("");

            

                }
            }
           
        }
 

        static string cekHuruf(string kata_rahasia, List<string> tebakanUser)
        {
            string output = "";
            for(int i=0 ; i<kata_rahasia.Length ; i++)
            {
                string c = Convert.ToString(kata_rahasia[i]);
                if(tebakanUser.Contains (c))
                {
                    output = output + c;
                }else
                {
                    output = output + "  * ";
                }
            }

            return output;    
        }

         static bool cekKata(string kata_rahasia, List<string> tebakanUser)
        {
            bool status = false;
            for(int i=0 ; i<kata_rahasia.Length ; i++)
            {
                string c = Convert.ToString(kata_rahasia[i]);
                if(tebakanUser.Contains(c))
                {
                    status = true;
                }else
                {
                    return status = false;
                }
            }

            return status;   
        }
    }
}
