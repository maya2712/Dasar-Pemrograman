﻿using System;
using System.Collections.Generic;

namespace Tebak_Kata_Desi.Mayasari
{
    class Program
    {
        static void Main(string[] args)
        {
            string kata = "kucing";
            int kesempatan = 5;
            List<string> hurufTebakanUser = new List<string>{};

            Console.WriteLine("Welcome to the guessing game");
            Console.WriteLine($"you have {kesempatan} chance for guess ");
            Console.WriteLine($"this word consist of {kata.Length} word");

            while (true){
                Console.Write("Your quess letter ");
                string input = Console.ReadLine();

                hurufTebakanUser.Add(input);
                if(cekKata(kata,hurufTebakanUser)){
                    Console.WriteLine("Congratulations The guess is ["+kata+"] ");
                    break;
                }else if(kata.Contains(input)){
                    Console.WriteLine("Your guess is correct ");
                    Console.WriteLine(cekHuruf(kata, hurufTebakanUser));
                }else{
                    Console.WriteLine("Oh no, your guess is Incorrect :( ");
                    kesempatan = kesempatan - 1;
                    Console.WriteLine("Your guess to stay "+kesempatan);
                }
                
                if(kesempatan == 0){
                    Console.WriteLine("Game Over, The guess is ["+kata+" ");
                    Console.WriteLine("See you next timeclear ");
                    break;
                }
            }
        }

        static string cekHuruf(string kata_rahasia, List<string> tebakanUser){
            string output = "";
            for(int i=0 ; i<kata_rahasia.Length ; i++){
                string c = Convert.ToString(kata_rahasia[i]);
                if(tebakanUser.Contains (c)){
                    output = output + c;
                }else{
                    output = output + "  * ";

                }
            }
            return output;    
        }

         static bool cekKata(string kata_rahasia, List<string> tebakanUser){
            bool status = false;
            for(int i=0 ; i<kata_rahasia.Length ; i++){
                string c = Convert.ToString(kata_rahasia[i]);
                if(tebakanUser.Contains(c)){
                    status = true;
                }else{
                    status = false;

                }
            }
            return status;   
        }
    }
}

