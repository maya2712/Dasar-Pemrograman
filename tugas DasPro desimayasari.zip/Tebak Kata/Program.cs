﻿using System;
using System.Collections.Generic;

namespace Tebak_Kata_Desi.Mayasari
{
    class Program
    {
        static void Main(string[] args)
        {
            string kata = "kucing";
            int kesempatan = 5;
            List<string> hurufTebakanUser = new List<string>{};

            Console.WriteLine("Selamat datang, mari bermain Game Tebak Kata");
            Console.WriteLine($"Kamu memiliki {kesempatan} kesempatan untuk menebak ");
            Console.WriteLine("Pentunjuknya adalah kata tersebut merupakan sebuah nama hewan");
            Console.WriteLine($"Kata ini terdiri dari {kata.Length} huruf");

            while (true){
                Console.Write("Apakah huruf tebakan mu? ");
                string input = Console.ReadLine();

                hurufTebakanUser.Add(input);
                if(cekKata(kata,hurufTebakanUser)){
                    Console.WriteLine("Selamat anda berhasil menang... ["+kata+"] ");
                    break;
                }else if(kata.Contains(input)){
                    Console.WriteLine("Selamat tebakan huruf mu benar ");
                    Console.WriteLine(cekHuruf(kata, hurufTebakanUser));
                }else{
                    Console.WriteLine("maaf tebakan huruf kamu salah :( ");
                    kesempatan = kesempatan - 1;
                    Console.WriteLine("Kesempatan kamu tersisah "+kesempatan);
                }
                
                if(kesempatan == 0){
                    Console.WriteLine("Game Over, tebakannya adalah ["+kata+" ");
                    Console.WriteLine("Sampai jumpa dahhhh... ");
                    break;
                }
            }
        }

        static string cekHuruf(string kata_rahasia, List<string> tebakanUser){
            string output = "";
            for(int i=0 ; i<kata_rahasia.Length ; i++){
                string c = Convert.ToString(kata_rahasia[i]);
                if(tebakanUser.Contains (c)){
                    output = output + c;
                }else{
                    output = output + "  * ";

                }
            }
            return output;    
        }

         static bool cekKata(string kata_rahasia, List<string> tebakanUser){
            bool status = false;
            for(int i=0 ; i<kata_rahasia.Length ; i++){
                string c = Convert.ToString(kata_rahasia[i]);
                if(tebakanUser.Contains(c)){
                    status = true;
                }else{
                    status = false;

                }
            }
            return status;   
        }
    }
}

