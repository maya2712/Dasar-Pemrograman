﻿using System;

namespace Dasar_Pemograman
{
    class Program
    {
        //Ini adalah main Function Saya
        static void Main(string[] args)
        {
         Console.WriteLine("Anda adalah agen rahasia yang bertugas mendapatkan data dari server");
         Console.WriteLine("Akses ke server membutuhkan password yang tidak diketahui...");
        
          // Deklarasi dan inisialisasi variabel
          // created by DMS

         const int codeA = 1;
         const int codeB = 2;
         const int codeC = 3;
         const int codeD = 4;
         int hasilTambah = 0;
         int hasilKali = 0;

         hasilTambah = codeA + codeB + codeC + codeD;
         hasilKali = codeA * codeB * codeC * codeD;

         Console.WriteLine("+ Kode Password terdiri dari 4 angka");
         Console.WriteLine("+ Hasil Penjumlahan Kode = "+hasilTambah);
         Console.WriteLine("+ Hasil Perkalian Kode = "+hasilKali);
         Console.Write("Enter Kode Pertama : ");
         string tebakanA = Console.ReadLine();
         Console.Write("Enter Kode Kedua : ");
         string tebakanB = Console.ReadLine();
         Console.Write("Enter Kode Ketiga : ");
         string tebakanC = Console.ReadLine();
         Console.Write("Enter Kode Keempat : ");
         string tebakanD = Console.ReadLine();

         Console.WriteLine("Tebakan Anda : " + tebakanA + tebakanB + tebakanC + tebakanD);

        }
    }
}
